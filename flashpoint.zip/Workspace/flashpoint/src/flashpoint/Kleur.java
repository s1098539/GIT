package flashpoint;

import java.awt.*;

/**
 * Created by Joep Oonk on 24-5-2017.
 */
public enum Kleur {
    ROOD,
    BLAUW,
    ZWART,
    ORANJE,
    GROEN,
    GEEL;
}


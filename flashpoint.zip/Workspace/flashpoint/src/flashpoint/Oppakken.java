package flashpoint;

public class Oppakken {

	public void run() {
		// TODO - implement Oppakken.run
		throw new UnsupportedOperationException();
	}

}
package flashpoint;

public class Lose {

	private int pVAsVermist;
	private int schadeAantal;

	public void check() {
		// TODO - implement Lose.check
		throw new UnsupportedOperationException();
	}

	public void pVAsVermistAdd() {
		// TODO - implement Lose.pVAsVermistAdd
		throw new UnsupportedOperationException();
	}

	public void schadeAantalAdd() {
		// TODO - implement Lose.schadeAantalAdd
		throw new UnsupportedOperationException();
	}

}
package flashpoint;

public class ExplosieHandler {

	public void run() {
		// TODO - implement ExplosieHandler.run
		throw new UnsupportedOperationException();
	}

}
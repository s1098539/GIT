package flashpoint;

public class Rook {

	public boolean aanwezig;

	public void maakVuur() {
		// TODO - implement Rook.maakVuur
		throw new UnsupportedOperationException();
	}

}
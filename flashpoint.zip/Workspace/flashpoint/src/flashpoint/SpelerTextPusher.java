package flashpoint;

public class SpelerTextPusher {

	private String tekst;

	public void push() {
		// TODO - implement SpelerTextPusher.push
		throw new UnsupportedOperationException();
	}

}
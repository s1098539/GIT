package flashpoint;

public class Mannetjesputter {

	private int AP;

}
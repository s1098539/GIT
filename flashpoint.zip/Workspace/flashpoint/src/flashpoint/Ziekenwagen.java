package flashpoint;

public class Ziekenwagen {

	public void links() {
		// TODO - implement Ziekenwagen.links
		throw new UnsupportedOperationException();
	}

	public void rechts() {
		// TODO - implement Ziekenwagen.rechts
		throw new UnsupportedOperationException();
	}

}
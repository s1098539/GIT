package flashpoint;

public class Taal {

	private String tekst;

}
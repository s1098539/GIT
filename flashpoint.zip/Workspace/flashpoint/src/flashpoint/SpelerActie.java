package flashpoint;

public class SpelerActie{

    public SpelerActie() {
    }

    public void createSpelerActie() {
        Bewegen bewegen = new Bewegen();
    }
}
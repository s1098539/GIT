package flashpoint;

public class Vuur {

	public boolean aanwezig;

	public void maakRook() {
		// TODO - implement Vuur.maakRook
		throw new UnsupportedOperationException();
	}

}
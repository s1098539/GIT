package flashpoint;

public class Reddingsspecialist {

	private int AP;
	private int EP;

	public void hakken() {
		// TODO - implement Reddingsspecialist.hakken
		throw new UnsupportedOperationException();
	}

	public void blussen() {
		// TODO - implement Reddingsspecialist.blussen
		throw new UnsupportedOperationException();
	}

}
package flashpoint;

public class OppakkenGS {

	public void run() {
		// TODO - implement OppakkenGS.run
		throw new UnsupportedOperationException();
	}

}
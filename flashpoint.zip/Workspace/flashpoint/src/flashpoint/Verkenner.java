package flashpoint;

public class Verkenner {

	private int AP;

	public void identificeren() {
		// TODO - implement Verkenner.identificeren
		throw new UnsupportedOperationException();
	}

}
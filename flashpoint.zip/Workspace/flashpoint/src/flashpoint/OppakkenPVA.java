package flashpoint;

public class OppakkenPVA {

	public void run() {
		// TODO - implement OppakkenPVA.run
		throw new UnsupportedOperationException();
	}

}
package flashpoint;

public class Commandant {

	private int AP;
	private int EP;

	public void geefOrder() {
		// TODO - implement Commandant.geefOrder
		throw new UnsupportedOperationException();
	}

}
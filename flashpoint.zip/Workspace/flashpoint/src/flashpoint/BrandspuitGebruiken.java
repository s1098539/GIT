package flashpoint;

public class BrandspuitGebruiken {

	private int quadrant;

	public void run() {
		// TODO - implement BrandspuitGebruiken.run
		throw new UnsupportedOperationException();
	}

}
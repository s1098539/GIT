package flashpoint;

public class GSHandler {

	public void run() {
		// TODO - implement GSHandler.run
		throw new UnsupportedOperationException();
	}

}
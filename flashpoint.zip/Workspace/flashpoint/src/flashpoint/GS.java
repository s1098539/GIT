package flashpoint;

public class GS {

	public boolean aanwezig;

}
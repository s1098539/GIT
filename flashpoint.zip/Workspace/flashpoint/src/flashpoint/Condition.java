package flashpoint;

public class Condition {

	public void check() {
		// TODO - implement Condition.check
		throw new UnsupportedOperationException();
	}

}
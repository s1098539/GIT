package flashpoint;

public class ChatBox {
}
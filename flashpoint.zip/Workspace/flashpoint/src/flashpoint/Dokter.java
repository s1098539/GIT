package flashpoint;

public class Dokter {

	private int AP;

	public void behandelen() {
		// TODO - implement Dokter.behandelen
		throw new UnsupportedOperationException();
	}

}
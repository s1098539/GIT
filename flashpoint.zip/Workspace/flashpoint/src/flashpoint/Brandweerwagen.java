package flashpoint;

public class Brandweerwagen {

	public void links() {
		// TODO - implement Brandweerwagen.links
		throw new UnsupportedOperationException();
	}

	public void rechts() {
		// TODO - implement Brandweerwagen.rechts
		throw new UnsupportedOperationException();
	}

	public void blussen() {
		// TODO - implement Brandweerwagen.blussen
		throw new UnsupportedOperationException();
	}

}
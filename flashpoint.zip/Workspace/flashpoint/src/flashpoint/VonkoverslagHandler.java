package flashpoint;

public class VonkoverslagHandler {

	public void run() {
		// TODO - implement VonkoverslagHandler.run
		throw new UnsupportedOperationException();
	}

}
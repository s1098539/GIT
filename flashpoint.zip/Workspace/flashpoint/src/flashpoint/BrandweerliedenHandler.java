package flashpoint;

public class BrandweerliedenHandler {

	public void run() {
		// TODO - implement BrandweerliedenHandler.run
		throw new UnsupportedOperationException();
	}

}
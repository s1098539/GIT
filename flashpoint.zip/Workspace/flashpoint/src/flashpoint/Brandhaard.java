package flashpoint;

public class Brandhaard {

	public boolean aanwezig;

}
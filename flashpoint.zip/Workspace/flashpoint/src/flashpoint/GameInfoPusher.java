package flashpoint;

public class GameInfoPusher {

	private String tekst;

	public void push() {
		// TODO - implement GameInfoPusher.push
		throw new UnsupportedOperationException();
	}

}
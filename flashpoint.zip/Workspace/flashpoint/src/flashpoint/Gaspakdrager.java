package flashpoint;

public class Gaspakdrager {

	private int AP;
	private int EP;

	public void blussen() {
		// TODO - implement Gaspakdrager.blussen
		throw new UnsupportedOperationException();
	}

}
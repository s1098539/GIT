package flashpoint;

public class Blussen {

	private int richting;

	public void run() {
		// TODO - implement Blussen.run
		throw new UnsupportedOperationException();
	}

}
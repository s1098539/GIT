package flashpoint;

public class BrandhaardHandler {

	public void run() {
		// TODO - implement BrandhaardHandler.run
		throw new UnsupportedOperationException();
	}

}
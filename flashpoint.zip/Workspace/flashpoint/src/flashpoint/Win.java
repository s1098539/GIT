package flashpoint;

public class Win {

	private int pVAsGered;

	public void check() {
		// TODO - implement Win.check
		throw new UnsupportedOperationException();
	}

	public void pVAsGeredAdd() {
		// TODO - implement Win.pVAsGeredAdd
		throw new UnsupportedOperationException();
	}

}
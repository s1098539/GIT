package flashpoint;

public class Functiewissel {

	private Character functie;

	public void run() {
		// TODO - implement Functiewissel.run
		throw new UnsupportedOperationException();
	}

}
package flashpoint;

public class Character {

	private Character[] Chararacers;

	public void createCharacters() {
		// TODO - implement Character.createCharacters
		throw new UnsupportedOperationException();
	}

}
package flashpoint;

public class SpecialistGS {

	private int AP;

	public void onschadelijkMaken() {
		// TODO - implement SpecialistGS.onschadelijkMaken
		throw new UnsupportedOperationException();
	}

}
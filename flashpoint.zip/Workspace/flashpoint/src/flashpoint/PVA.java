package flashpoint;

public class PVA {

	public boolean aanwezig;

}
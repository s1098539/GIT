package flashpoint;

public interface Object {
}
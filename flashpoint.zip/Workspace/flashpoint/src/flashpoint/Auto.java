package flashpoint;

public interface Auto {

	void links();

	void rechts();

}
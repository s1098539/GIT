package flashpoint;

public class Rijden {

	private int quadrant;

	public void links() {
		// TODO - implement Rijden.links
		throw new UnsupportedOperationException();
	}

	public void rechts() {
		// TODO - implement Rijden.rechts
		throw new UnsupportedOperationException();
	}

}
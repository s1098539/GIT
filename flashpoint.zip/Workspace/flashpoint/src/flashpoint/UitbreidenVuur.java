package flashpoint;

public class UitbreidenVuur {

	public void run() {
		// TODO - implement UitbreidenVuur.run
		throw new UnsupportedOperationException();
	}

}
package sample.Model;

/**
 * Created by Lenovo on 6/19/2017.
 */
public interface ModelInterface {
    public void testPrint(){

    }
}
